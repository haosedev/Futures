<?php 
/**
 * GameServer
 */
namespace Server;
use \Workerman\Worker;
use \Workerman\Lib\Timer;
use \Server\Events;
use \Server\Messages;

require_once __DIR__ . '/Constants.php';

class GameServer {
    
    public $id;
    public $maxPlayers;
    public $server;
    public $ups;
    public $players = array();
    public $outgoingQueues = array();
    public $itime = null;     //当前时间
    public $TodayData;        //准备一个object
    public $lastMorningTime;    //上次开盘时间，开盘后保存时间，防止重复操作
    public $lastCloseTime;      //上次收盘时间，收盘后保存时间，防止重复操作
    
    public function __construct($id, $maxPlayers, $websocketServer) {
        
        $this->id = $id;
        $this->maxPlayers = $maxPlayers;
        $this->server = $websocketServer;
        $this->ups = 5;
        $this->isOfferTime = false;     //进入交易时间
        $this->status=-1;                //状态：-1刚启动系统，0收盘状态，1开盘中准备中，2交易状态，3收盘准备中。
        $this->playerCount = 0;
        $this->players = array();
        $this->outgoingQueues = array();
        $this->itime=time();
        
        
        $self = $this;
        $this->DataReady(); //准备数据
        
        $this->onPlayerConnect(function ($player)use($self) {

        });
        
        $this->onPlayerEnter(
                function($player) use ($self){
                    
                    //echo $player->name . " has joined ". $self->id."\n";
                    debuglog($player->name ."(".$player->id.") has joined ". $self->id);
                
                    if(!$player->hasEnteredGame) {
                        $self->incrementPlayerCount();
                    }
                
                    // $moveCallback = function($x, $y) use($player, $self){
                        // echo $player->name . " is moving to (" . $x . ", " . $y . ")\n";
                
                        // $player->forEachAttacker(function($mob) use($player, $self) {
                            // $target = $self->getEntityById($mob->target);
                            // if($target) 
                            // {
                                // $pos = $self->findPositionNextTo($mob, $target);
                                // if($mob->distanceToSpawningPoint($pos['x'], $pos['y']) > 50) 
                                // {
                                    // $mob->clearTarget();
                                    // $mob->forgetEveryone();
                                    // $player->removeAttacker($mob);
                                // } 
                                // else 
                                // {
                                    // $self->moveEntity($mob, $pos['x'], $pos['y']);
                                // }
                            // }
                        // });
                    // };
                
                    // $player->onMove($moveCallback);
                    // $player->onLootMove($moveCallback);
                
                    $player->onExit(function() use($self, $player){
                        //echo $player->name . " has left the System.\n";
                        debuglog($player->name ."(".$player->id.") has left the System");
                        
                        $self->removePlayer($player);
                        $self->decrementPlayerCount();
                
                        if(isset($self->removedCallback)) {
                            call_user_func($self->removedCallback);
                        }
                    });
                
                    // if(isset($self->addedCallback)) {
                        // call_user_func($self->addedCallback);
                    // }
                }
            );
    }
    //启动数据处理
    public function DataReady(){
        //服务器启动时，把数据库数据读取到缓存中。
        global $db;
        //$date=$db->row("SELECT daytime FROM `Pricelist` order by daytime desc");
        $dateKey=$db->select('daytime')->from('Pricelist')->orderByDESC(array('daytime'))->single();
        //$this->TodayData = $db->query("SELECT p.*,s.name FROM `Pricelist` p left join `Stock` s on p.code=s.code where p.daytime='".$dateKey."'");
        $this->TodayData = $db->select('p.*,s.name')->from('Pricelist p')->innerJoin('Stock s','p.code=s.code')->where('p.daytime = :item')->bindValues(array('item' => $dateKey))->query();
        //判断当前数据是否处于
        $now_key=date("YmdH");
        $now_min=date("i");
        //状态：-1刚启动系统，0收盘状态，1开盘中准备中，2交易状态，3收盘准备中。
        if (($now_key===$dateKey)&&($now_min<55)){
            //当前还处于报价状态，继续当前开盘状态
            $this->doMorning(); //开盘
        }else if($now_key>$dateKey){
            //这里有两种状态。1是否开盘时间。
            if ($now_min<55){
                //新一日开盘
                $this->doMorning(true); //重新开盘
            }
        }else{
            $this->status = 0;
            $this->isOfferTime=false;
        }
    }
    //开盘
    public function doMorning($isNewDay=false){
        $now_key=date("YmdH");
        if ($this->lastMorningTime!=$now_key){
            $this->status = 1;
            if ($isNewDay){ //新一日重新开盘
                foreach($this->TodayData as $k=>$v){
                    $this->TodayData[$k]['yestoday_price']=$v['now_price'];
                    $this->TodayData[$k]['start_price']=$v['now_price'];
                    $this->TodayData[$k]['daytime']=$now_key;
                    $this->TodayData[$k]['ud_price']=0;
                    $this->TodayData[$k]['ud_precent']=0;
                    $this->TodayData[$k]['max_up']=intval($v['now_price']*1.1);       //涨停
                    $this->TodayData[$k]['max_down']=intval($v['now_price']*0.9);     //跌停
                }
            }
            $this->lastMorningTime=$now_key;
            $this->status = 2;
            $this->isOfferTime=true;
            debuglog("Market Offer starting !!");
        }
    }
    //收盘
    public function doClose(){
        $this->isOfferTime=false;
        $now_key=date("YmdH");
        if ($this->lastCloseTime!=$now_key){  //不是保存状态时才操作
            $this->status = 3;
            global $db;
            //**收盘写入数据库，当前数据保留当明日开盘
            foreach($this->TodayData as $k=>$v){
                $item=$db->select('id')->from('Pricelist')->where('code = :code and daytime = :item')->bindValues(array('code'=>$v['code'],'item' => $now_key))->single();
                if (!$item){
                    //插入数据
                    $insert_id = $db->insert('Pricelist')->cols([
                        'code'=>$v['code'],
                        'daytime'=>$now_key,
                        'yestoday_price'=>$v['yestoday_price'],
                        'start_price'=>$v['start_price'],
                        'now_price'=>$v['now_price'],
                        'ud_price'=>$v['ud_price'],
                        'ud_precent'=>$v['ud_precent']])->query();
                }
            }
            $this->lastCloseTime=$now_key;
            $this->status = 0;
            debuglog("Market Offer closing !!");
        }
    }
    //群发当前盘面数据给某人
    public function SendAllDataToPlayer($player){
        foreach($this->TodayData as $v){
            $this->pushToPlayer($player, new Messages\Offer($v));
        }
    }
    public function BroadcastAllData(){
        foreach($this->TodayData as $v){
            $this->pushBroadcast(new Messages\Offer($v));
        }
    }    
    public function run(){
        
        $self = $this;

        Timer::add(1/$this->ups, function() use ($self) {
            //$self->processGroups();
            $self->TimeControl();           //时间事件切换（开盘，收盘）
            $self->processVirtualOffer();   //虚拟交易事件
            $self->processQueues();         //广播事件
        });
        
        debuglog($this->id." Server is created capacity: ".$this->maxPlayers." players");
    }
    
    public function setUpdatesPerSecond($ups) {
        $this->ups = $ups;
    }
    
    public function onInit($callback) {
        $this->initCallback = $callback;
    }

    public function onPlayerConnect($callback) {
        $this->connectCallback = $callback;
    }
    
    public function onPlayerEnter($callback) {
        $this->enterCallback = $callback;
    }
    
    public function onPlayerAdded($callback) {
        $this->addedCallback = $callback;
    }
    
    public function onPlayerRemoved($callback) {
        $this->removedCallback = $callback;
    }
    //新增用户
    public function addPlayer($player) {
        $this->players[$player->id] = $player;
        $this->outgoingQueues[$player->id] = array();
    }
    //移除用户
    public function removePlayer($player) {
          
        unset($this->players[$player->id], 
              $this->outgoingQueues[$player->id]);
              
        $player->destroy();     //摧毁
    }
    
    //对某个player发送消息
    public function pushToPlayer($player, $message) {
        if($player && isset($this->outgoingQueues[$player->id])) {
            $this->outgoingQueues[$player->id][] = $message->serialize();
        } else {
            debuglog("pushToPlayer: player was undefined");
        }
    }  
    //广播，对所有人发送消息
    public function pushBroadcast($message, $ignoredPlayer = null) {
        foreach($this->outgoingQueues as $id=>$item){
            if($id != $ignoredPlayer){
                $this->outgoingQueues[$id][] = $message->serialize();
            }
        }
    }
    //开收盘切换
    public function TimeControl(){
        //假设每小时开盘一次，收盘一次，5分钟修正，整点开盘，55分收盘
        $nowTime=date('is');//分钟秒  0000  0分0秒
        if ($nowTime==="0000"){     //每小时头开盘0000
            //开盘
            $this->doMorning(true);  //准点触发新开盘
            $this->BroadcastAllData();
        }else if ($nowTime==="5500"){   //每小时尾收盘5500
            //收盘
            $this->doClose();  //准点触发收盘
        }
    }  
    //自动事件队列处理
    public function processVirtualOffer() {
        //
        if ($this->isOfferTime){      //交易时间
            $tick=1;    //超过1秒可以更新
            //**随机选择一只做调整
            //**随机根据股票数量产生轮空时间计算公式
            //**每只股票自我计算概率是否更新，更新范围大小，如果更新范围是0也就不更新
            //**
            foreach($this->TodayData as $k=>$v){
                
                if (empty($v['lastChange'])){
                    $this->TodayData[$k]['lastChange']=time();
                    continue;
                }
                $chance=time()-$v['lastChange'];
                //
                $canDoChange=($chance>Rand(0,3))?true:false;
                if ($canDoChange){
                    $this->TodayData[$k]['lastChange']=time();      //更新时间
                    //单次涨跌幅度 0% - 0.5%   -50 ~ 50
                    $cPrecent=(Rand(0,100)-50)/10000;     //
                    $price_change=$v['start_price']*$cPrecent;       //计算并自动取整（小于
                    if ($price_change!=0){
                        if ($price_change>0)
                            $price_change=ceil($price_change);      //向上取整，小数位稳进
                        else
                            $price_change=floor($price_change);      //向下取整，小数位稳进
                        $new_price=$v['now_price']+$price_change;
                        
                        //还要判断涨跌停判断
                        if ($new_price>$v['max_up']) $new_price=$v['max_up'];
                        else if ($new_price<$v['max_down']) $new_price=$v['max_down'];
                        
                        if ($new_price!=$this->TodayData[$k]['now_price']){
                            
                            $this->TodayData[$k]['now_price']=$new_price;
                            //$this->TodayData[$k]['ud_price']+=$price_change;     //这里算法有bug
                            $this->TodayData[$k]['ud_price']=$new_price-$v['start_price'];
                            
                            $ud_precent=($this->TodayData[$k]['ud_price']/$v['start_price'])*10000;
                            //涨跌百分比
                            if ($ud_precent>0)
                                $ud_precent=ceil($ud_precent);      //向上取整，小数位稳进
                            else
                                $ud_precent=floor($ud_precent);      //向下取整，小数位稳进
                            
                            $this->TodayData[$k]['ud_precent']=$ud_precent;
                        
                            //**SendChangetoAll
                            $this->pushBroadcast(new Messages\Offer($this->TodayData[$k]));
                        }
                    }
                }
            }
            
        }
        
    }
    //消息队列处理
    public function processQueues() {
        foreach($this->outgoingQueues as $id=>$item){
            if($this->outgoingQueues[$id]) {
                if (isset($this->server->connections[$id])) {
                    $connection = $this->server->connections[$id];
                    $connection->send(json_encode($this->outgoingQueues[$id]));
                }else{
                    debuglog("connect is closed and can't send message !");
                }
                $this->outgoingQueues[$id] = array();
            }
        }
    }
    
    public function forEachPlayer($callback) {
        foreach($this->players as $player){
            call_user_func($callback, $player);
        }
    }
    
    public function getPlayerCount() {
        $count = 0;
        foreach($this->players as $p => $player){
            if($this->players->hasOwnProperty($p)){
                $count += 1;
            }
        }
        return $count;
    }
    
    public function setPlayerCount($count) {
        $this->playerCount = $count;
    }
    
    public function incrementPlayerCount() {
        $this->setPlayerCount($this->playerCount + 1);
    }
    
    public function decrementPlayerCount() {
        if($this->playerCount > 0) {
            $this->setPlayerCount($this->playerCount - 1);
        }
    }
    
    public function onConnect($connection)
    {
        $connection->onWebSocketConnect = array($this, 'onWebSocketConnect');
    }
    
    public function onWebSocketConnect($connection)
    {
        
    }
}
