<?php 
/**
 * 常用常量定义
 */

define('TYPES_MESSAGES_SYSTEM', 0);
define('TYPES_MESSAGES_HELLO', 1);
define('TYPES_MESSAGES_WELCOME', 2);
define('TYPES_MESSAGES_MESSAGE', 3);
define('TYPES_PING', 9);
define('TYPES_MESSAGES_OFFER', 10);      //单品报价


