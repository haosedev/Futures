<?php
/**
 * SearchEvents
 * 外出搜索事件
 *
 */
namespace Server\Events;
use \Server;

class OfferEvents extends Events{
    
    public $player=null;
    public $MyNpc=array();      //派遣人物
    //下面是否做到返回时再根据实际情况处理
    public $items=array();      //可返回物品列表
    public $level=0;            //难度等级
    public $ability=array();    //综合加成
    
    
    public function __construct($time, $player){
        
        parent::__construct($time);     //继承使用基类的构造
        $this->player = $player;       
        $this->items = Server\Types::$settingOfSearch['Items'];
        $this->ability = Server\Types::$settingOfSearch['Chance'];
        
    }
    
    public function checkNPC($MyNpc){
        //在这里可以检测一下NPC是否待命状态，并且把npc的特殊加成写入列表
        
        
        
    }
    
    protected function RandItems(){
        //p($this->items);
        //随机取
        $allTickets=array_sum($this->ability);
        foreach ($this->ability as $k => $v) {   
            $randNum = Rand(1, $allTickets);               
            if ($randNum <= $v) {   
                $result = $k;                         
                break;   
            } else {   
                $allTickets -= $v;                       
            }   
        }
        if ($result>0){
            $rst['Number'] = Rand($this->items[$result]['rand'][0], $this->items[$result]['rand'][1]);
        }
        $rst['key']=$this->items[$result]['key'];
        $rst['ext']="";
        if ($rst['Number']){
            $rst['ext']="(".$rst['Number'].")";
        }
        debuglog('Events:find:'.$rst['key'].$rst['ext']);
        //**改写用户数据
        
        
        return $rst;
    }
    
    public function doTrigger($time){   //必须在子类中实现
        
        $rst=$this->RandItems();
        //下次发送包，要改成发送SeacrhReturn包
        $this->player->send(json_encode(array(TYPES_MESSAGES_MESSAGE, Server\Types::getSearchMessage($rst['key']).$rst['ext'])));
        
    }      
}