<?php 
/**
 * 游戏数据控制
 * 仅控制数据，不参与交流
 */
namespace Server;

class GameData {
    
    //Base
    private $GD["LEVEL"]    = 1;
    private $GD['HITPOINT'] = 100;
    private $GD['MANA']     = 100;
    private $GD['ATT']      = 1;
    private $GD['DEF']      = 1;
    //
    
    //Max
    private $MAX["LEVEL"]    = 9;
    private $MAX['HITPOINT'] = 9999;
    private $MAX['MANA']     = 9999;
    private $MAX['ATT']      = 99;
    private $MAX['DEF']      = 99;
    
    
    public function __construct($data_arr){
        
        if (count($data_arr)>0){
            $this->GD=$data_arr;
            $this->MAX=calc($data_arr);
        }else{
            
        }
        
    }

    
}
