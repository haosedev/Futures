<?php
/**
 * This file is class for Database.
 *
 */
namespace Server;
use \Workerman\Worker;

class Datebase{

    private $db = null;

    /*******************
     * 判断数据库是否连接
     * 
     *******************/
    public function isReady(){
        if ($this->db) return true;
        return false;
    }
    /*******************
     * 初始化数据库
     * 
     *******************/
    public function __construct($username, $password, $dbName, $host='localhost',$port='3306') {
        $this->db = new \Workerman\MySQL\Connection($host, $port, $username, $password, $dbName);
        if ($this->db) return true;
        return false;
    }
    /*******************
     * 用户登陆
     * 
     *******************/
    public function UserLogin($user='', $pwd=''){
        return $this->db->select('*')->from('User u')->where('u.username = :user and u.password = :pwd ')->bindValues(array('user' => $user,'pwd'=> $pwd))->row();
    }
    /*******************
     * 用户持仓数据
     * 
     *******************/
    public function getUserKeep($uid=0){
        return $this->db->select('k.*,s.name')->from('KeepStock k')->innerJoin('Stock s','k.code=s.code')->where('uid = :uid and num>0 ')->bindValues(array('uid' => $uid))->query();
    }
    /*******************
     * 更新用户数据
     * 
     *******************/
    public function UpdateUserInfo($info){
        $tmp=$info;
        unset($tmp['id']);
        $tmp['update_time']=time();
        $this->db->update('User')->cols($tmp)->where('ID='.$info['id'])->query();
    }

    /////////////////////////////////////////////////////大盘数据/////////////////////////////////////////////////////
    /*******************
     * 获取最新DataKey
     * 
     *******************/
    public function getDataKey(){
        //$date=$db->row("SELECT daytime FROM `Pricelist` order by daytime desc");
        return $this->db->select('daytime')->from('Pricelist')->orderByDESC(array('daytime'))->single();
    }
    /*******************
     * 获取某DataKey的每股数据
     * 
     *******************/
    public function getTodayData($dateKey){
        //$this->TodayData = $db->query("SELECT p.*,s.name FROM `Pricelist` p left join `Stock` s on p.code=s.code where p.daytime='".$dateKey."'");
        return  $this->db->select('p.*,s.name')->from('Pricelist p')->innerJoin('Stock s','p.code=s.code')->where('p.daytime = :item')->bindValues(array('item' => $dateKey))->query();
        
    }
    /*******************
     * 写入单只数据（如果已存在就放弃写入）
     * 
     *******************/
    public function saveDataSingle($now_key,$info){
        $item=$this->db->select('id')->from('Pricelist')->where('code = :code and daytime = :item')->bindValues(array('code'=>$info['code'],'item' => $now_key))->single();
        if (!$item){
            //插入数据
            $insert_id = $this->db->insert('Pricelist')->cols([
                'code'=>$info['code'],
                'daytime'=>$now_key,
                'yestoday_price'=>$info['yestoday_price'],
                'start_price'=>$info['start_price'],
                'now_price'=>$info['now_price'],
                'ud_price'=>$info['ud_price'],
                'ud_precent'=>$info['ud_precent']])->query();
        }
    }
    /*******************
     * 写入大盘数据（如果存在就放弃写入）
     * 
     *******************/
    public function saveMarketAll($now_key, $MarketAllData){
        $market=$this->db->select('id')->from('MarketAll')->where('daytime = :item')->bindValues(array('item' => $now_key))->single();
        if (!$market){
            //插入数据
            $insert_id = $this->db->insert('MarketAll')->cols([
                'daytime'=>$MarketAllData['daytime'],
                'yestoday_price'=>$MarketAllData['yestoday_price'],
                'start_price'=>$MarketAllData['start_price'],
                'now_price'=>$MarketAllData['now_price'],
                'ud_price'=>$MarketAllData['ud_price'],
                'ud_precent'=>$MarketAllData['ud_precent']])->query();
        }
    }









}
