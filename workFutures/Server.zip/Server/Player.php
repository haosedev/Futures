<?php 
/**
 * 
 */
namespace Server;
use \Workerman\Lib\Timer;
use \Server\Events;

error_reporting(E_ALL^E_NOTICE);

class Player {
    
    public $hasEnteredSystem = FALSE;
    public $disconnectTimeout = 0;
    public $connection;
    public $server;
    public $id=0;
    public $sn_id=null;       //数据序列
    public $isLogin=FALSE;    //登录状态
    public $userInfo;         //用户数据
    public $KeepStock=[];     //持仓数据
    
    public function __construct($connection, $gameServer){
        
        $this->server = $gameServer;
        $this->connection = $connection;
        
        $this->id=$this->connection->id;        //直接使用id
        $this->name="NONAME";
        //$this->hasEnteredSystem = FALSE;
        $this->isDead = FALSE;
        $this->KeepStock = [];
        $this->disconnectTimeout = 0;
        $this->connection->onMessage = array($this, 'onClientMessage');
        $this->connection->onClose = array($this, 'onClientclose');
        $this->connection->onWebSocketConnect = function($con) {
            //$con->send(json_encode(array(TYPES_MESSAGES_HELLO)));
            //$con->send("go");
        };
        //**添加用户（本来应该在认证完成时候添加的）
        //$this->server->addPlayer($this);
    }
    
    public function onClientMessage($connection, $data){
        
        $message = json_decode($data, true);
        if (is_array($message)){
            $action = $message[0];
        }else{
            debuglog(" Error Message !");
            return;
        }
        if((!$this->hasEnteredSystem) && ($action !== TYPES_MESSAGES_HELLO)){
            $this->connection->close(json_encode(array(TYPES_MESSAGES_SYSTEM,"Invalid handshake message: ". $data)));
            return;
        }
        $this->resetTimeout();
        
        if($action === TYPES_MESSAGES_HELLO) {
            
            //$name = preg_replace('/^( |\s)*|( |\s)*$/', '', $message[1]);       //头尾去空格
            $this->name =  "ANONYMOUS".Rand(100000,999999) ;
            
            $this->server->addPlayer($this);
            call_user_func($this->server->enterCallback, $this);
            
            $this->connection->send(json_encode(array(TYPES_MESSAGES_WELCOME, $this->id, $this->name)));
            $this->hasEnteredSystem = true;
            //第一次要发全量数据给用户，向系统请求一个全量数据吧
            $this->server->StockServer->SendAllDataToPlayer($this);
            
        }elseif($action == TYPES_LOGIN){
            global $db, $datebase;
            if (!$this->isLogin){
                //$name = preg_replace('/^( |\s)*|( |\s)*$/', '', $message[1]));       //头尾去空格 
                $name = preg_replace('/\s+/', '', $message[1]);       //去掉所有空格 
                //$pwd = preg_replace('/^( |\s)*|( |\s)*$/', '', $message[2]));        //头尾去空格 
                $pwd = preg_replace('/\s+/', '', $message[2]);        //去掉所有空格 

                if ($name){
                    //$tmp = $db->select('*')->from('User u')->where('u.username = :user and u.password = :pwd ')->bindValues(array('user' => $name,'pwd'=> $pwd))->row();
                    $tmp = $datebase->UserLogin($name, $pwd);
                    if ($tmp){
                        $this->isLogin=true;
                        $tmp['login_time']=time();
                        $this->userInfo=$tmp;
                        debuglog("UserLogin:[".$this->name."] ChangeNameTo [".$tmp['nickname']."]");
                        $this->name=$tmp['nickname'];
                        $this->pushToPlayer(new Messages\LoginAnswer(true,"登录成功！"));
                    }else{
                        // //**用户错误
                        $this->pushToPlayer(new Messages\LoginAnswer(false,"登录失败！"));
                        return;
                    }
                }
            }else{
                $this->pushToPlayer(new Messages\LoginAnswer(true,"已是登录状态！"));
            }
            //更新登录信息
            $this->UpdateUserInfo();
            $this->sendUserInfo();
            //**然后去读取持仓信息
            //$this->KeepStock = $db->select('k.*,s.name')->from('KeepStock k')->innerJoin('Stock s','k.code=s.code')->where('uid = :uid and num>0 ')->bindValues(array('uid' => $this->userInfo['id']))->query();
            $this->KeepStock = $datebase->getUserKeep($this->userInfo['id']);
            //
            $this->sendKeepStock();
            
        }elseif($action == TYPES_PING){
            //接收 ping 信息
            //debuglog($this->name . " SEND PING !");
        }
        // else if($action === TYPES_MESSAGES_ZONE) {
            // call_user_func($this->zoneCallback);
        // }
        // else if($action == TYPES_MESSAGES_CHAT) 
        // {
            // $msg = trim($message[1]);
            
            // // Sanitized messages may become empty. No need to broadcast empty chat messages.
            // if($msg) 
            // {
                // $this->broadcastToZone(new Messages\Chat($this, $msg), false);
            // }
        // }
        // else if($action == TYPES_MESSAGES_MOVE) {
            // if($this->moveCallback) 
            // {
                // $x = $message[1];
                // $y = $message[2];
                
                // if($this->server->isValidPosition($x, $y)) {
                    // $this->setPosition($x, $y);
                    // $this->clearTarget();
                    
                    // $this->broadcast(new Messages\Move($this));
                    // call_user_func($this->moveCallback, $this->x, $this->y);
                // }
            // }
        // }
        // else if($action == TYPES_MESSAGES_LOOTMOVE) {
            // if($this->lootmoveCallback) 
            // {
                // $this->setPosition($message[1], $message[2]);
                
                // $item = $this->server->getEntityById($message[3]);
                // if($item) 
                // {
                    // $this->clearTarget();
                    // $this->broadcast(new Messages\LootMove($this, $item));
                    // call_user_func($this->lootmoveCallback, $this->x, $this->y);
                // }
            // }
        // }
        // else if($action == TYPES_MESSAGES_AGGRO) {
            // if($this->moveCallback) 
            // {
                // $this->server->handleMobHate($message[1], $this->id, 5);
            // }
        // }
        // else if($action == TYPES_MESSAGES_ATTACK) {
            // $mob = $this->server->getEntityById($message[1]);
            // if($mob) 
            // {
                // $this->setTarget($mob);
                // $this->server->broadcastAttacker($this);
            // }
        // }
        // else if($action == TYPES_MESSAGES_HIT) {
            // $mob = $this->server->getEntityById($message[1]);
            // if($mob) 
            // {
                // $dmg = Formulas::dmg($this->weaponLevel, $mob->armorLevel);
                
                // if($dmg > 0 && is_callable(array($mob, 'receiveDamage')))
                // {
                    // $mob->receiveDamage($dmg, $this->id);
                    // $this->server->handleMobHate($mob->id, $this->id, $dmg);
                    // $this->server->handleHurtEntity($mob, $this, $dmg);
                // }
            // }
        // }
        // else if($action == TYPES_MESSAGES_HURT) {
            // $mob = $this->server->getEntityById($message[1]);
            // if($mob && $this->hitPoints > 0) 
            // {
                // $this->hitPoints -= Formulas::dmg($mob->weaponLevel, $this->armorLevel);
                // $this->server->handleHurtEntity($this);
                
                // if($this->hitPoints <= 0) 
                // {
                    // $this->isDead = true;
                    // if(!empty($this->firepotionTimeout)) 
                    // {
                        // Timer::del($this->firepotionTimeout);
                        // $this->firepotionTimeout = 0;
                    // }
                // }
            // }
        // }
        // else if($action == TYPES_MESSAGES_LOOT) {
            // $item = $this->server->getEntityById($message[1]);
            
            // if($item) 
            // {
                // $kind = $item->kind;
                
                // if(Types::isItem($kind)) 
                // {
                    // $this->broadcast($item->despawn());
                    // $this->server->removeEntity($item);
                    
                    // if($kind == TYPES_ENTITIES_FIREPOTION) {
                        // $this->updateHitPoints();
                        // $this->broadcast($this->equip(TYPES_ENTITIES_FIREFOX));
                        // $this->firepotionTimeout = Timer::add(15, array($this, 'firepotionTimeoutCallback'), array(), false);
                        // $hitpoints = new Messages\HitPoints($this->maxHitPoints);
                        // $data = $hitpoints->serialize();
                        // $this->connection->send(json_encode($data));
                    // } 
                    // else if(Types::isHealingItem($kind)) {
                        // $amount = 0;
                        // switch($kind) 
                        // {
                            // case TYPES_ENTITIES_FLASK: 
                                // $amount = 40;
                                // break;
                            // case TYPES_ENTITIES_BURGER: 
                                // $amount = 100;
                                // break;
                        // }
                        
                        // if(!$this->hasFullHealth()) 
                        // {
                            // $this->regenHealthBy($amount);
                            // $this->server->pushToPlayer($this, $this->health());
                        // }
                    // } 
                    // else if(Types::isArmor($kind) || Types::isWeapon($kind)) {
                        // $this->equipItem($item);
                        // $this->broadcast($this->equip($kind));
                    // }
                // }
            // }
        // }
        // else if($action == TYPES_MESSAGES_TELEPORT) {
            // $x = $message[1];
            // $y = $message[2];
            
            // if($this->server->isValidPosition($x, $y)) 
            // {
                // $this->setPosition($x, $y);
                // $this->clearTarget();
                
                // $this->broadcast(new Messages\Teleport($this));
                
                // $this->server->handlePlayerVanish($this);
                // $this->server->pushRelevantEntityListTo($this);
            // }
        // }
        // else if($action == TYPES_MESSAGES_OPEN) {
            // $chest = $this->server->getEntityById($message[1]);
            // if($chest && $chest instanceof Chest) 
            // {
                // $this->server->handleOpenedChest($chest, $this);
            // }
        // }
        // else if($action == TYPES_MESSAGES_CHECK) {
            // $checkpoint = $this->server->map->getCheckpoint($message[1]);
            // if($checkpoint) 
            // {
                // $this->lastCheckpoint = $checkpoint;
            // }
        // }
        // else 
        // {
            // if(isset($this->messageCallback)) 
            // {
                // call_user_func($this->messageCallback, $message);
            // }
        // }
    }
    
    public function onClientClose(){
        // Timer::del($this->disconnectTimeout);
        // $this->disconnectTimeout = 0;
        if(isset($this->exitCallback)) {
            call_user_func($this->exitCallback);
        }
    }
    //保存用户信息
    private function UpdateUserInfo(){
        
        if ($this->isLogin && ($this->userInfo['id']>0)){
            //写入数据库
            global $db, $datebase;
            // $tmp=$this->userInfo;
            // unset($tmp['id']);
            // $tmp['update_time']=time();
            // $db->update('User')->cols($tmp)->where('ID='.$this->userInfo['id'])->query();
            $datebase->UpdateUserInfo($this->userInfo);
            return true;
        }
        return false;
    }
    public function sendUserInfo(){
        $this->pushToPlayer(new Messages\UserInfo($this->userInfo));
    }
    //发送持仓信息
    public function sendKeepStock(){
        foreach($this->KeepStock as $v){
            $this->pushToPlayer(new Messages\MarketKeep($v));
        }
    }
    
    public function destroy() {
        //销毁前保存
        $this->UpdateUserInfo();
        debuglog("destroy player(".$this->id.")");
        Timer::del($this->disconnectTimeout);
    }
    
    public function send($message) {
        $this->connection->send($message);
    }
    
    public function pushToPlayer($message){
        $this->server->pushToPlayer($this, $message);
    }
    
    public function onExit($callback){
         $this->exitCallback = $callback;
    }
    
    public function onMessage($callback) {
        $this->messageCallback = $callback;
    }
    //重新设置，无响应时间（每55秒用户无响应向用户发起一次timeout）
    public function resetTimeout() {
        Timer::del($this->disconnectTimeout);
        // 15分钟
        $this->disconnectTimeout = Timer::add(55, array($this, 'timeout'), false);
    }
    
    public function timeout() {
        
        //debuglog("Player (".$this->id.") was idle for too long then to close connected!");
        //$this->connection->close(json_encode(array(TYPES_MESSAGES_SYSTEM,"timeout: ")));
        // $this->connection->send('timeout');
        debuglog("Player (".$this->id.") was idle for too long!");
    }

}
